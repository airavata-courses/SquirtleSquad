module.exports = {
    MongoURI: "mongodb+srv://anuragkumar:Qwerty@123@cluster0-mbssp.mongodb.net/test?retryWrites=true&w=majority"
}