
module.exports = {
    MongoURI: "mongodb+srv://sathyan:1234@sathyan-cluster-jj8km.mongodb.net/test"
}